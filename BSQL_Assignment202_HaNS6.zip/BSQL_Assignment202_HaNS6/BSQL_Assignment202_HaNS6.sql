-- Create a new database called 'FresherTrainingManagement'
-- Connect to the 'master' database to run this snippet
USE master
GO
-- Create the new database if it does not exist already
IF NOT EXISTS (
    SELECT [name]
        FROM sys.databases
        WHERE [name] = N'FresherTrainingManagement'
)
CREATE DATABASE FresherTrainingManagement
GO
-------------------- QUESTION 1 ----------------------------
CREATE TABLE Trainee
(
    TraineeID INT PRIMARY KEY IDENTITY(1,1),
    Full_Name NVARCHAR(100),
    Birth_Date DATE,
    Gender BIT,
    ET_IQ INT CHECK(ET_IQ BETWEEN 0 AND 20),
    ET_Gmath INT CHECK(ET_Gmath BETWEEN 0 AND 20),
    ET_English INT CHECK(ET_English BETWEEN 0 AND 50),
    Training_Class VARCHAR(8),
    Evaluation_Notes TEXT
)
GO
------------------------INSERT DATA---------------------------------
INSERT INTO Trainee(Full_Name,Birth_Date,Gender,ET_IQ,ET_Gmath,ET_English,Evaluation_Notes,Fsoft_Account) VALUES 
('DO VAN GIANG','2000-07-07',1,20,20,30,'ACADEMIC PRETTY',1),
('NGUYEN VAN BAC','2000-08-07',1,9,9,25,'WEAK LEARNING CAPACITY',2),
('NGUYEN THI THUY DUNG','2000-09-07',1,7,7,15,'WEAK LEARNING CAPACITY',3),
('DO VAN XOI','2000-06-07',1,15,15,50,'ACADEMIC PRETTY',4),
('HUONG VAN GIANG','2000-10-07',1,15,20,30,'ACADEMIC PRETTY',5),
('DAVID BECKHAM', '1989-10-09',1,15,15,40,'ACADEMIC PRETTY',6)
GO
------------------------------QUESTION 2----------------------------
ALTER TABLE Trainee
ADD Fsoft_Account INT NOT NULL
GO

ALTER TABLE Trainee
ADD CONSTRAINT UQ_Trainee_Fsoft_Account UNIQUE(Fsoft_Account)
GO
-----------------------------QUESTION 3------------------------------
CREATE VIEW ET_Passed
AS
SELECT t.TraineeID, t.Full_Name, t.Birth_Date, t.ET_IQ, t.ET_Gmath, t.ET_English 
FROM Trainee t
WHERE (t.ET_IQ + t.ET_Gmath) >= 20 AND t.ET_IQ >= 8 
AND t.ET_Gmath >=8 AND t.ET_English >=18
GO

SELECT * FROM ET_Passed
GO
---------------------------QUESTION 4-------------------------------
SELECT t.TraineeID, t.Full_Name, t.Birth_Date, t.ET_IQ, t.ET_Gmath, t.ET_English 
FROM Trainee t
WHERE (t.ET_IQ + t.ET_Gmath) >= 20 AND t.ET_IQ >= 8 
AND t.ET_Gmath >=8 AND t.ET_English >=18
ORDER BY MONTH(t.Birth_Date)
GO
---------------------------QUESTION 5-------------------------------
SELECT t.TraineeID, t.Full_Name,t.Birth_Date, YEAR((GETDATE())-YEAR(t.Birth_Date)) AS AGE 
FROM Trainee t
WHERE LEN(t.Full_Name) = (SELECT MAX(LEN(t.Full_Name)) FROM Trainee t)




